﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    class People : List<Person>
    {
        public People()
        {
            Add(new Person() { Name = "박내환", Age = "24", Grade = "3", Ban = "1", Number = "1", Gender = "남" });
            Add(new Person() { Name = "이민호", Age = "24", Grade = "3", Ban = "1", Number = "2", Gender = "남" });
            Add(new Person() { Name = "이지한", Age = "22", Grade = "3", Ban = "1", Number = "3", Gender = "남" });
            Add(new Person() { Name = "박창현", Age = "23", Grade = "3", Ban = "1", Number = "4", Gender = "남" });
            Add(new Person() { Name = "이주희", Age = "22", Grade = "3", Ban = "1", Number = "5", Gender = "여" });
        }

    }
}
