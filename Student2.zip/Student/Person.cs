﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    class Person
    {
        public string Name { get; set; }
        public string Age { get; set; }
        public string Grade { get; set; }
        public string Ban { get; set; }
        public string Number { get; set; }
        public string Gender { get; set; }

        public override string ToString()
        {
            return Name + "," + Age + "," + Grade + "," + Ban + "," + Number + "," + Gender;
        }
    }
}
