﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace Student
{
    /// <summary>
    /// ClassInfo.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ClassInfo : Page
    {
        static Button btn;
        List<StudentInfo> items = new List<StudentInfo>();

        public ClassInfo()
        {
            InitializeComponent();
        }

        private void button25_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(
                    new Uri(@"\student.xaml", UriKind.Relative)
                    );
        }

        private void btnSit1_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit2_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit3_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit4_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit5_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit6_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit7_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit8_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit9_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit10_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit11_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit12_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit13_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit14_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit15_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit16_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit17_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit18_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit19_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void btnSit20_Click(object sender, RoutedEventArgs e)
        {
            btn = sender as Button;
        }

        private void button21_Click(object sender, RoutedEventArgs e)
        {
            if (btn == button)
            {
                button.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if(btn == button2)
            {
                button2.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button3)
            {
                button3.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button4)
            {
                button4.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button5)
            {
                button5.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button6)
            {
                button6.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button7)
            {
                button7.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button8)
            {
                button8.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button9)
            {
                button9.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button10)
            {
                button10.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button11)
            {
                button11.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button12)
            {
                button12.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button13)
            {
                button13.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button14)
            {
                button14.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button15)
            {
                button15.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button16)
            {
                button16.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button17)
            {
                button17.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button18)
            {
                button18.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button19)
            {
                button19.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
            else if (btn == button20)
            {
                button20.Background = button21.Background;
                MessageBox.Show("출석완료");
            }
        }   

        private void button22_Click(object sender, RoutedEventArgs e)
        {
            if (btn == button)
            {
                button.Background = button22.Background;
            }
            else if (btn == button2)
            {
                button2.Background = button22.Background;
            }
            else if (btn == button3)
            {
                button3.Background = button22.Background;
            }
            else if (btn == button4)
            {
                button4.Background = button22.Background;
            }
            else if (btn == button5)
            {
                button5.Background = button22.Background;
            }
            else if (btn == button6)
            {
                button6.Background = button22.Background;
            }
            else if (btn == button7)
            {
                button7.Background = button22.Background;
            }
            else if (btn == button8)
            {
                button8.Background = button22.Background;
            }
            else if (btn == button9)
            {
                button9.Background = button22.Background;
            }
            else if (btn == button10)
            {
                button10.Background = button22.Background;
            }
            else if (btn == button11)
            {
                button11.Background = button22.Background;
            }
            else if (btn == button12)
            {
                button12.Background = button22.Background;
            }
            else if (btn == button13)
            {
                button13.Background = button22.Background;
            }
            else if (btn == button14)
            {
                button14.Background = button22.Background;
            }
            else if (btn == button15)
            {
                button15.Background = button22.Background;
            }
            else if (btn == button16)
            {
                button16.Background = button22.Background;
            }
            else if (btn == button17)
            {
                button17.Background = button22.Background;
            }
            else if (btn == button18)
            {
                button18.Background = button22.Background;
            }
            else if (btn == button19)
            {
                button19.Background = button22.Background;
            }
            else if (btn == button20)
            {
                button20.Background = button22.Background;
            }
        }

        private void button23_Click(object sender, RoutedEventArgs e)
        {
            if (btn == button)
            {
                button.Background = button23.Background;
            }
            else if (btn == button2)
            {
                button2.Background = button23.Background;
            }
            else if (btn == button3)
            {
                button3.Background = button23.Background;
            }
            else if (btn == button4)
            {
                button4.Background = button23.Background;
            }
            else if (btn == button5)
            {
                button5.Background = button23.Background;
            }
            else if (btn == button6)
            {
                button6.Background = button23.Background;
            }
            else if (btn == button7)
            {
                button7.Background = button23.Background;
            }
            else if (btn == button8)
            {
                button8.Background = button23.Background;
            }
            else if (btn == button9)
            {
                button9.Background = button23.Background;
            }
            else if (btn == button10)
            {
                button10.Background = button23.Background;
            }
            else if (btn == button11)
            {
                button11.Background = button23.Background;
            }
            else if (btn == button12)
            {
                button12.Background = button23.Background;
            }
            else if (btn == button13)
            {
                button13.Background = button23.Background;
            }
            else if (btn == button14)
            {
                button14.Background = button23.Background;
            }
            else if (btn == button15)
            {
                button15.Background = button23.Background;
            }
            else if (btn == button16)
            {
                button16.Background = button23.Background;
            }
            else if (btn == button17)
            {
                button17.Background = button23.Background;
            }

            else if (btn == button18)
            {
                button18.Background = button23.Background;
            }
            else if (btn == button19)
            {
                button19.Background = button23.Background;
            }
            else if (btn == button20)
            {
                button20.Background = button23.Background;
            }
        }

        private void button24_Click(object sender, RoutedEventArgs e)
        {
            if (btn == button)
            {
                button.Background = button24.Background;
            }
            else if (btn == button2)
            {
                button2.Background = button24.Background;
            }
            else if (btn == button3)
            {
                button3.Background = button24.Background;
            }
            else if (btn == button4)
            {
                button4.Background = button24.Background;
            }
            else if (btn == button5)
            {
                button5.Background = button24.Background;
            }
            else if (btn == button6)
            {
                button6.Background = button24.Background;
            }
            else if (btn == button7)
            {
                button7.Background = button24.Background;
            }
            else if (btn == button8)
            {
                button8.Background = button24.Background;
            }
            else if (btn == button9)
            {
                button9.Background = button24.Background;
            }
            else if (btn == button10)
            {
                button10.Background = button24.Background;
            }
            else if (btn == button11)
            {
                button11.Background = button24.Background;
            }
            else if (btn == button12)
            {
                button12.Background = button24.Background;
            }
            else if (btn == button13)
            {
                button13.Background = button24.Background;
            }
            else if (btn == button14)
            {
                button14.Background = button24.Background;
            }
            else if (btn == button15)
            {
                button15.Background = button24.Background;
            }
            else if (btn == button16)
            {
                button16.Background = button24.Background;
            }
            else if (btn == button17)
            {
                button17.Background = button24.Background;
            }
            else if (btn == button18)
            {
                button18.Background = button24.Background;
            }
            else if (btn == button19)
            {
                button19.Background = button24.Background;
            }
            else if (btn == button20)
            {
                button20.Background = button24.Background;
            }
        }

        private void btn_show_Click(object sender, RoutedEventArgs e)
        {
            items.Add(new StudentInfo() { Name = "박내환", Grade = "3", Classes = "1", StuNumber = "1", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "이민호", Grade = "3", Classes = "1", StuNumber = "2", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "박창현", Grade = "3", Classes = "1", StuNumber = "3", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "이지한", Grade = "3", Classes = "1", StuNumber = "4", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "이주희", Grade = "3", Classes = "1", StuNumber = "5", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "박길동", Grade = "3", Classes = "1", StuNumber = "6", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "이길동", Grade = "3", Classes = "1", StuNumber = "7", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "황길동", Grade = "3", Classes = "1", StuNumber = "8", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "홍길동", Grade = "3", Classes = "1", StuNumber = "9", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "김길동", Grade = "3", Classes = "1", StuNumber = "10", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "박OO", Grade = "3", Classes = "1", StuNumber = "11", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "이OO", Grade = "3", Classes = "1", StuNumber = "12", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "하OO", Grade = "3", Classes = "1", StuNumber = "13", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "유OO", Grade = "3", Classes = "1", StuNumber = "14", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "강OO", Grade = "3", Classes = "1", StuNumber = "15", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "홍OO", Grade = "3", Classes = "1", StuNumber = "16", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "권OO", Grade = "3", Classes = "1", StuNumber = "17", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "공OO", Grade = "3", Classes = "1", StuNumber = "18", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "한OO", Grade = "3", Classes = "1", StuNumber = "19", Data = DateTime.Now });
            items.Add(new StudentInfo() { Name = "임OO", Grade = "3", Classes = "1", StuNumber = "20", Data = DateTime.Now });
            listView.ItemsSource = items;
        }

    }
}

