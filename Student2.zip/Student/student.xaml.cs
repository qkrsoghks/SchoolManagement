﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Student
{
    /// <summary>
    /// student.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class student : Page
    {
        private People people = new People();
        private Person per;

        public student()
        {
            InitializeComponent();

            per = people[0];
            updateNameToUI();
            updateAgeToUI();
            updateGradeToUI();
            updateBanToUI();
            updateNumberToUI();
            updateGenderToUI();
            updateListBox();
        }

        private void updateNameToUI()
        {
            if(per == null)
            {
                name.Text = "";
                nameLabel1.Content = "";
            }
            else
            {
                name.Text = per.Name;
                nameLabel1.Content = per.Name;
            }
        }

        private void updateAgeToUI()
        {
            if (per == null)
            {
                age.Text = "";
                ageLabel.Content = "";
            }
            else
            {
                age.Text = per.Age;
                ageLabel.Content = per.Age;
            }
        }

        private void updateGradeToUI()
        {
            if (per == null)
            {
                grade.Text = "";
                gradeLabel.Content = "";
            }
            else
            {
                grade.Text = per.Grade;
                gradeLabel.Content = per.Grade;
            }
        }

        private void updateBanToUI()
        {
            if (per == null)
            {
                ban.Text = "";
                banLabel.Content = "";
            }
            else
            {
                ban.Text = per.Ban;
                banLabel.Content = per.Ban;
            }
        }

        private void updateNumberToUI()
        {
            if (per == null)
            {
                number.Text = "";
                numberLabel.Content = "";
            }
            else
            {
                number.Text = per.Number;
                numberLabel.Content = per.Number;
            }
        }

        private void updateGenderToUI()
        {
            if (per == null)
            {
                gender.Text = "";
                genderLabel.Content = "";
            }
            else
            {
                gender.Text = per.Gender;
                genderLabel.Content = per.Gender;
            }
        }

        private void updateListBox()
        {
            listbox.Items.Clear();
           foreach(Person p in people)
            {
                listbox.Items.Add(p.ToString());
            }
        }

        private void name_TextChanged(object sender, TextChangedEventArgs e)
        {
            per.Name = name.Text;
        }

        private void age_TextChanged(object sender, TextChangedEventArgs e)
        {
            per.Age = age.Text;
        }

        private void grade_TextChanged(object sender, TextChangedEventArgs e)
        {
            per.Grade = grade.Text;
        }

        private void ban_TextChanged(object sender, TextChangedEventArgs e)
        {
            per.Ban = ban.Text;
        }

        private void number_TextChanged(object sender, TextChangedEventArgs e)
        {
            per.Number = number.Text;
        }

        private void gender_TextChanged(object sender, TextChangedEventArgs e)
        {
            per.Gender = gender.Text;
        }

        private void listbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listbox.SelectedIndex >= 0)
            {
                per = people[listbox.SelectedIndex];
                updateNameToUI();
                updateAgeToUI();
                updateGradeToUI();
                updateBanToUI();
                updateNumberToUI();
                updateGenderToUI();
            }
        }

        private void addbutton_Click(object sender, RoutedEventArgs e)
        {
            if(name.Text=="" || age.Text==""|| grade.Text==""|| ban.Text == "" || number.Text == "" || gender.Text == "")
            {
                return;
            }
            people.Add(new Person() { Name = name.Text, Age = age.Text, Grade = grade.Text, Ban = ban.Text, Number = number.Text, Gender = gender.Text });
            updateListBox();
        }

        private void removebutton_Click(object sender, RoutedEventArgs e)
        {
            if (listbox.SelectedIndex >= 0)
            {
                people.RemoveAt(listbox.SelectedIndex);

                if (people.Count == 0)
                {
                    per = null;
                }
                else
                {
                    per = people[0];
                }
                updateNameToUI();
                updateAgeToUI();
                updateGradeToUI();
                updateBanToUI();
                updateNumberToUI();
                updateGenderToUI();
                updateListBox();
            }
        }

        private void updatebutton_Click(object sender, RoutedEventArgs e)
        {
            if(name.Text == ""|| age.Text=="" || grade.Text==""|| ban.Text==""|| number.Text==""|| gender.Text == "")
            {
                return;
            }
            per.Name = name.Text;
            per.Age = age.Text;
            per.Grade = grade.Text;
            per.Ban = ban.Text;
            per.Number = number.Text;
            per.Gender = gender.Text;

            updateNameToUI();
            updateAgeToUI();
            updateGradeToUI();
            updateBanToUI();
            updateNumberToUI();
            updateGenderToUI();
            updateListBox();
        }
    }
}
