﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    class StudentInfo
    {
        public string Name { get; set; }
        public string Grade { get; set; }
        public string Classes { get; set; }
        public string StuNumber { get; set; }
        public DateTime Data { get; set; }

        public override string ToString()
        {
            return Name + Grade + Classes + StuNumber + Data;
        }
    }
}
