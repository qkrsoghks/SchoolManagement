﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Student
{
    /// <summary>
    /// statics.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class statics : Page
    {
        public statics()
        {
            InitializeComponent();
        }

        private void comboBox_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox.Items.Add("2018");
            comboBox.Items.Add("2019");
            comboBox.Items.Add("2020");
        }

        private void comboBox2_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox2.Items.Add("1");
            comboBox2.Items.Add("2");
            comboBox2.Items.Add("3");
            comboBox2.Items.Add("4");
            comboBox2.Items.Add("5");
            comboBox2.Items.Add("6");
        }

        private void comboBox3_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox3.Items.Add("1");
            comboBox3.Items.Add("2");
            comboBox3.Items.Add("3");
            comboBox3.Items.Add("4");
            comboBox3.Items.Add("5");
            comboBox3.Items.Add("6");
        }

        private void comboBox1_Loaded(object sender, RoutedEventArgs e)
        {
            comboBox1.Items.Add("1");
            comboBox1.Items.Add("2");
        }

        private void button_Click(object sender, RoutedEventArgs e)   
        {
            comboBox1.Text = comboBox1.SelectedItem.ToString();//학기
            comboBox.Text = comboBox.SelectedItem.ToString(); // 학년도
            comboBox2.Text = comboBox2.SelectedItem.ToString(); //학년
            comboBox3.Text = comboBox3.SelectedItem.ToString(); //반
            if (comboBox1.Text == "1" &&comboBox.Text =="2018" && comboBox2.Text=="1" && comboBox3.Text=="1") //2018학년도 1학년 1반 1학기 
            {
                NavigationService.Navigate(
                     new Uri(@"\Page1.xaml", UriKind.Relative)
                     );
            }
            else
            {
                MessageBox.Show("조회 할 수 없습니다.");
            }
        }
    }
}
